// App.js
import React from 'react';
import Card from './Card';
import './Card.css'; // Import the CSS file for styling
import backg from './images/img1.jpeg'
import sli1 from './images/slider-img3.jpeg'
import sli2 from './images/slider-img1.png'
import profile from './images/profile.jpeg'







const App = () => {
  const cards = [
    
    {
      
      tags: ['AI/ML', 'DSA'],
      likes: 120,
      ratings: 5.0,
      modalImage: backg,
      modalText: 'This is the text which will be displayed.',
      contactImage: profile,
      contactName: 'Jane Done',
      
      
      additionalImages: [sli1, sli2, backg],
     
      aboutProjectText: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      feedbackHeading: 'Rating and Feedback',
      feedbackArray: [
        { heading: 'Tanmay Mittal',
        image:profile,
         text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
         date:'22/09/2024',
         stars:5 },
        {
          heading: 'Priyanshu',
          image:profile,
          text:'hello',
          date:'22/22/2342',
          stars:4
        }
        ,
        {
          heading: 'Priyanshu',
          image:profile,
          text:'hellovtvgvbuv',
          date:'22/22/2342',
          stars:4
        }

        
      ]
    },
    // Add more cards as needed
  ];

  return (
    <div className="app-container">
      

      <div className="cards-box">
        {cards.map((card, index) => (
          <Card
            key={index}
            
            tags={card.tags}
            likes={card.likes}
            ratings={card.ratings}
            modalImage={card.modalImage}
            modalText={card.modalText}
            contactImage={card.contactImage}
            contactName={card.contactName}
            collaborateImage={card.collaborateImage}
            
            additionalImages={card.additionalImages}
            
            aboutProjectText={card.aboutProjectText}
            feedbackHeading={card.feedbackHeading}
            feedbackArray={card.feedbackArray}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
