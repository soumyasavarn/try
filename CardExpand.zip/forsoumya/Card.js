// CardWithModal.js
import React, { useState } from "react";
//import Modal from 'react-modal';
import like from "./images/like.svg";
import cross from "./images/cross.svg";
import star from "./images/star.svg";
import unstar from "./images/unstared.svg";
import downarrow from "./images/Arrow.svg";
import FeedbackComponent from "./Feedback";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import { Pagination } from "swiper";

const Card = ({
  tags,
  likes,
  ratings,
  modalImage,
  modalText,
  contactImage,
  contactName,
  additionalImages,
  aboutProjectText,
  feedbackHeading,
  feedbackArray,
}) => {
  return (
    <div id="main">
      <div id="project1"></div>
      <div id="details-main">
        <div id="details">
          <div id="banner">
            <img src={modalImage} alt="" id="banner-image" />
            <div id="layer"></div>
            <img src={cross} id="cross" />
            <div id="inf">
              <h1>{modalText}</h1>
              <div id="inf2">
                <div id="like">
                  <img src={like} alt="" /> {likes}
                </div>
                <div id="line"></div>
                <div id="rate">
                  <img src={star} alt="" /> {ratings}
                </div>
              </div>
            </div>
          </div>
          <div id="deltails-page1">
            <div id="contactor">
              <div id="profile">
                <img src={contactImage} id="profile-picture" alt="" />
                <span id="name" />
                {contactName}
              </div>
              <div id="linker">
                <button id="getInTouch">Get In Touch</button>
                <button id="Collaborate">Collaborate</button>
              </div>
            </div>

            <div id="display-img">
              <div class="swiper">
                <div class="swiper-wrapper">
                  {/* <div class="swiper-slide"><img src="./Images/slider-img1.png" alt=""/>Resize me!</div>
                              <div class="swiper-slide"><img src="./Images/Slider-img2.png" alt=""/>Resize me!</div>
                              <div class="swiper-slide"><img src="./Images/slider-img3.jpeg" alt=""/>Resize me!</div>
                              <div class="swiper-slide">Resize me!</div>
                              <div class="swiper-slide">Resize me!</div>
                              <div class="swiper-slide">Resize me!</div>
                              <div class="swiper-slide">Resize me!</div>
                              <div class="swiper-slide">Resize me!</div>
                              <div class="swiper-slide">Resize me!</div>
                              <div class="swiper-slide">Resize me!</div> */}
                  <Swiper
                    spaceBetween={50}
                    slidesPerView={1}
                    pagination={{ clickable: true }}
                  >
                    {additionalImages.map((image, index) => (
                      <SwiperSlide key={index}>
                        <div class="swiper-slide">
                            <img src={image} alt={`Slide ${index}`} />
                        </div>
                      </SwiperSlide>
                    ))}
                  </Swiper>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
              </div>
            </div>

            <div id="description-tags">
              <div id="description">
                <h1>About this project</h1>
                <div id="description-part2">{aboutProjectText}</div>
              </div>
              <div id="tags">
                {/* <a href="#" id="UX" class="tags">UX/UI</a>
                            <a href="#" id="Java" class="tags">Java</a>
                            <a href="#" id="AI" class="tags">AI</a> */}
                {tags.map((tag, index) => (
                  <a href="#" id="UX" class="tags">
                    {" "}
                    <span key={index}>{tag}</span>
                  </a>
                ))}
              </div>
            </div>

            <div id="feedbacks-ratting">
              <h1>Rating and Feedback</h1>
              <div id="ratting">
                <img src={contactImage} class="feedback-pic" alt="" />
                <div class="profile-id">
                  <div class="profile-name">{contactName}</div>
                  <form id="submiting" action="#">
                    <div class="stars">
                      <img
                        src="./Images/unstared.svg"
                        class="star star-s"
                        data-rating="1"
                        alt=""
                      />
                      <img
                        src="./Images/unstared.svg"
                        class="star star-s"
                        data-rating="2"
                        alt=""
                      />
                      <img
                        src="./Images/unstared.svg"
                        class="star star-s"
                        data-rating="3"
                        alt=""
                      />
                      <img
                        src="./Images/unstared.svg"
                        class="star star-s"
                        data-rating="4"
                        alt=""
                      />
                      <img
                        src="./Images/unstared.svg"
                        class="star star-s"
                        data-rating="5"
                        alt=""
                      />
                    </div>
                    <input type="date" id="date" value="" />
                  </form>
                </div>
                <div id="addFeedbackButton">
                  <div id="nox">
                    <span>Write a feedback</span>
                    <img src={downarrow} id="FeedBackDownButton" alt="" />
                  </div>
                </div>
              </div>
              <div id="text">
                <input
                  type="text"
                  id="feedBackText"
                  placeholder="Describe your view..."
                />
                <button type="submit">Submit</button>
              </div>

              
                <div>
                    <FeedbackComponent feedbackArray={feedbackArray}/>
                </div>   
                
              
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
