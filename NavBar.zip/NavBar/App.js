// App.js
import React from 'react';
import Navbar from './navbar.js';


const App = () => {

  

  return (
    <>
    <Navbar/>
    <h1 style={{ color: 'blue' }}>laa</h1>
    </>
  );
};

export default App;
