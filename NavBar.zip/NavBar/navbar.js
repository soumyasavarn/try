import React, { useState } from 'react';
import { Switch } from 'react-router-dom';
import { Link, BrowserRouter, Route } from "react-router-dom";
import './navbar.css';
import Explore from './Explore.js';
import Chats from './Chats.js';

const Navbar = () => {
  const [selectedButton, setSelectedButton] = useState("explore");

  const handleButtonClick = (buttonId) => {
    setSelectedButton(buttonId);
  };

  return (
    <div id="main">
      <div id="layer0"></div>
      <div id="layer1"></div>
      <div id="layer2"></div>
      <div id="layer3"></div>
      <BrowserRouter>
        <nav>
          <img src="./Images/logo.png" style={{ height: '35px' }} id="logo" alt=""/>
          <div id="search">
            <input type="text" name="" id="" placeholder="Search" />
            <img src="./Images/search.svg" alt=""/>
          </div>
          <div id="nav-part2">
            <Link to="/" className={`nav-link ${selectedButton === "explore" ? "selected" : ""}`} onClick={() => handleButtonClick("explore")}>Explore</Link>
            <Link to="/Chats" className={`nav-link ${selectedButton === "chats" ? "selected" : ""}`} onClick={() => handleButtonClick("chats")}>Chats</Link>
            <Link to="/Profile" className={`nav-link ${selectedButton === "profile" ? "selected" : ""}`} onClick={() => handleButtonClick("profile")}>Profile</Link>
          </div>
        </nav>
        <Switch>
          <Route exact path="/">
            <Explore />
          </Route>
          <Route exact path="/Chats">
            <Chats />
          </Route>
          <Route exact path="/Profile">
            {/* Component for Profile */}
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
};

export default Navbar;
